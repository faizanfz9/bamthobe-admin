const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const cors = require("cors");
const passport = require("passport");
const mongoose = require("mongoose");
const config = require("./config/db");

const app = express();
const users = require("./routes/users");
const PORT = process.env.PORT || 3000;

// connect to database
mongoose.connect(config.database, {
    useUnifiedTopology: true,
    useNewUrlParser: true
});

// on connection
mongoose.connection.on("connected", () => {
    console.log("Connected to database" + config.database);
});

// on error
mongoose.connection.on("error", (err) => {
    console.log("Database error" + err);
});

// body parser middleware
app.use(bodyParser.json());

// passport middleware
app.use(passport.initialize());
app.use(passport.session());

require("./config/passport")(passport)

// cors middleware
app.use(cors());

// routes
app.use("/api/users", users);

// index route
app.get("/", function(req, res){
    res.send("Hello World");
})

// start server
app.listen(PORT, function(){
    console.log("Server has been started on " + PORT);
})