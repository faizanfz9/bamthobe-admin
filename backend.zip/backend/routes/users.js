const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const config = require("../config/db");
const passport = require("passport");
const User = require("../models/user");

router.post("/register", function(req, res, next){
    let newUser = new User({
        name: req.body.name,
        email: req.body.email,
        usertype: req.body.usertype,
        password: req.body.password
    });

    User.getUserByEmail(newUser.email, (err, user) => {
        if(err) throw err;
        if(user) {
            res.json({success: false, msg: "User already registered"});
        }else {
            User.addUser(newUser, (err, user) => {
                if(err) {
                    res.json({success: false, msg: "Failed to register user"});
                }else {
                    res.json({success: true, msg: "User registered"});
                }
            })
        }
    })
})

router.post("/login", function(req, res, next){
    const email = req.body.email;
    const password = req.body.password;

    User.getUserByEmail(email, (err, user) => {
        if(err) throw err;
        if(!user) {
            return res.json({success: false, msg: "User not found"});
        }
        
        User.comparePassword(password, user.password, (err, isMatch) => {
            if(err) throw err;
            if(isMatch) {
                const token = jwt.sign({user}, config.secret, {
                    expiresIn: 604800
                });

                res.json({
                    success: true,
                    token: "JWT "+token,
                    user: {
                        id: user._id,
                        name: user.name,
                        email: user.email
                    }
                })
            }else {
                console.log(user.password);
                return res.json({success: false, msg: "Wrong Password"});
            }
        })
    })
})

module.exports = router;