module.exports = {
    database: "mongodb+srv://faizan:UbuPREMmydFeaihm@cluster0.pzzii.mongodb.net/bamthobe?retryWrites=true&w=majority",
    secret: "yoursecret"
};